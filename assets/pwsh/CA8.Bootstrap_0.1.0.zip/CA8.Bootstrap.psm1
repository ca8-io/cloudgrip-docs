
function New-AzDevOpsPipelineFiles {
  [CmdLetBinding(SupportsShouldProcess = $true)]
  Param(
    [Parameter(Mandatory)]
    [System.IO.FileInfo] $Path
  )

  begin {
    $pipelineFiles = @(
      @{
        Name    = 'sync-mangementgroup-config.yml'
        Content = '
trigger: none

parameters:
  - name: agents
    displayName: Agent Pool to use
    type: string
    values:
      - microsoft
      - self-hosted
    default: self-hosted

jobs:
  - job: SyncManagementGroupConfig
    displayName: Sync Managementgroup Config
    ${{ if eq(parameters[agents], self-hosted) }}:
      pool: ca8-cloudgrip
    ${{ if eq(parameters[agents], microsoft) }}:
      pool:
        vmImage: ubuntu-22.04
    steps:
      - checkout: self
        fetchDepth: 1

      - task: AzurePowerShell@5
        inputs:
          azureSubscription: "CloudGrip"
          ScriptType: "FilePath"
          ScriptPath: "scripts/pipeline/Sync-ManagementGroupsConfig.ps1"
          ScriptArguments: >-
            -InformationAction Continue
          azurePowerShellVersion: "LatestVersion"
          pwsh: true
          InformationActionPreference: "Continue"
  '
      }
      @{
        Name    = 'sync-subscription-config.yml'
        Content = '
trigger: none

parameters:
  - name: agents
    displayName: Agent Pool to use
    type: string
    values:
      - microsoft
      - self-hosted
    default: self-hosted

jobs:
  - job: SyncSubscriptionConfig
    displayName: Sync Subscription Config
    ${{ if eq(parameters[agents], self-hosted) }}:
      pool: ca8-cloudgrip
    ${{ if eq(parameters[agents], microsoft) }}:
      pool:
        vmImage: ubuntu-22.04
    steps:
      - checkout: self
        fetchDepth: 1

      - task: AzurePowerShell@5
        inputs:
          azureSubscription: "CloudGrip"
          ScriptType: "FilePath"
          ScriptPath: "scripts/pipeline/Sync-SubscriptionConfig.ps1"
          ScriptArguments: >-
            -InformationAction Continue
          azurePowerShellVersion: "LatestVersion"
          pwsh: true
          InformationActionPreference: "Continue"
        '
      })
  }

  process {
    foreach ($pipelineFile in $pipelineFiles) {
      $savePath = Join-Path -Path $Path -ChildPath $pipelineFile.Name
      $pipelineFile.Content | Out-File -FilePath $savePath -Encoding utf8 -Force
    }
  }

  end {}
}

function New-GitHubWorkflowFiles {
  [CmdLetBinding(SupportsShouldProcess = $true)]
  Param(
    [Parameter(Mandatory)]
    [System.IO.FileInfo] $Path
  )

  begin {
    $workflowFiles = @(
      @{
        Name    = 'sync-mangementgroup-config.yml'
        Content = '
  name: Sync Managementgroup Config

  on:
    workflow_dispatch:
      inputs:
        runs-on:
          type: choice
          description: Runs on
          required: true
          default: self-hosted
          options:
            - ubuntu-latest
            - self-hosted
    push:
      paths:
        - Azure/**
      branches:
        - main

  defaults:
    run:
      shell: pwsh

  permissions:
    id-token: write
    contents: read

  jobs:
    ManagementGroupConfigSync:
      runs-on: ${{ github.event.inputs.runs-on }}
      steps:
        - name: Checkout repository
          uses: actions/checkout@v2

        - name: Azure login
          uses: azure/login@v1
          with:
              client-id: ${{vars.CLOUDGRIPAZURECLIENTID}}
              tenant-id: ${{vars.CLOUDGRIPAZURETENANTID}}
              enable-AzPSSession: true
              allow-no-subscriptions: true

        - name: Sync Managementgroup Config
          run: |
            $InformationPreference = Continue;
            Write-Information -MessageData "Starting configuration for managementgroups.";
            Sync-CA8ManagementGroups -ConfigurationFolderPath ${{GITHUB.WORKSPACE}};
            Get-CA8ManagementGroupRbac -ConfigurationFolderPath ${{GITHUB.WORKSPACE}} | Sync-CA8RBAC -Confirm:$false;
            Write-Information -MessageData "Finished configuration for managementgroups.";
          env:
            GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
  '
      }
      @{
        Name    = 'sync-subscription-config.yml'
        Content = '
  name: Sync Subscription Config

  on:
    workflow_dispatch:
      inputs:
        runs-on:
          type: choice
          description: Runs on
          required: true
          default: self-hosted
          options:
            - ubuntu-latest
            - self-hosted
    push:
      paths:
        - Azure/**
      branches:
        - main

  defaults:
    run:
      shell: pwsh

  permissions:
    id-token: write
    contents: read

  jobs:
    SubscriptionConfigSync:
      runs-on: ${{ github.event.inputs.runs-on }}
      steps:
        - name: Checkout repository
          uses: actions/checkout@v2

        - name: Azure login
          uses: azure/login@v1
          with:
              client-id: ${{vars.CLOUDGRIPAZURECLIENTID}}
              tenant-id: ${{vars.CLOUDGRIPAZURETENANTID}}
              enable-AzPSSession: true
              allow-no-subscriptions: true

        - name: Subscription Config Sync
          run: |
            $InformationPreference = Continue;
            Sync-CA8Subscriptions -ConfigurationFolderPath ${{GITHUB.WORKSPACE}};
          env:
            GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
  '
      })
  }

  process {
    foreach ($workflowFile in $workflowFiles) {
      $savePath = Join-Path -Path $Path -ChildPath $workflowFile.Name
      $workflowFile.Content | Out-File -FilePath $savePath -Encoding utf8 -Force
    }
  }

  end {}
}

function New-VSCodeSettingsFile {
  [CmdLetBinding(SupportsShouldProcess = $true)]
  Param(
    [Parameter(Mandatory)]
    [System.IO.FileInfo] $Path
  )
  $content = '
  {
    "editor.insertSpaces": true,
    "editor.tabSize": 2,
    "editor.detectIndentation": false,
    "editor.formatOnSave": true,
    "files.trimTrailingWhitespace": true,
    "files.trimFinalNewlines": true,
    "files.insertFinalNewline": true,
    "files.eol": "\n",
    "files.encoding": "utf8",
    "powershell.codeFormatting.preset": "OTBS",
    "powershell.codeFormatting.alignPropertyValuePairs": true,
    "powershell.codeFormatting.whitespaceInsideBrace": true,
    "powershell.codeFormatting.whitespaceBeforeOpenParen": true,
    "powershell.codeFormatting.whitespaceBeforeOpenBrace": true,
    "powershell.codeFormatting.addWhitespaceAroundPipe": true,
    "powershell.codeFormatting.whitespaceAroundOperator": true,
    "powershell.codeFormatting.whitespaceAfterSeparator": true,
    "powershell.codeFormatting.useCorrectCasing": true,
    "yaml.format.singleQuote": true
  }
'
  $content | Out-File -FilePath $Path -Encoding utf8 -Force
}

<#
  .SYNOPSIS
  The synopsis of the new function

  .DESCRIPTION
  The description of the new function

  .PARAMETER Path
  The name of the parameter

  .PARAMETER DevOpsSystem
  The name of the parameter

  .EXAMPLE
  #Azure DevOps
  New-CA8CloudGripSetup -Path ./cg-azd -DevOpsSystem AzureDevOps

  #Github
  New-CA8CloudGripSetup -Path ./cg-gh -DevOpsSystem GitHub
#>
function New-CA8CloudGripSetup {
  [CmdLetBinding(SupportsShouldProcess = $true)]
  Param(
    [Parameter()]
    [System.IO.FileInfo] $Path = './CloudGripConfig',

    [Parameter(Mandatory)]
    [ValidateSet('AzureDevOps', 'GitHub')]
    [string] $DevOpsSystem
  )

  begin {

  }
  process {
    if ($PSCmdlet.ShouldProcess($Path, 'Create CloudGrip folderstructure')) {
      if ($null -eq (Test-Path -Path $Path)) {
        $null = New-Item -Path $Path -ItemType Directory -Force
      }
      #region Setup Azure DevOps Config
      if ($DevOpsSystem -eq 'AzureDevOps') {
        $null = New-Item -Path "$Path/.azuredevops" -ItemType Directory -Force
        $azDevOpsPipelinePath = New-Item -Path "$Path/.azuredevops/pipelines" -ItemType Directory -Force
        New-AzDevOpsPipelineFiles -Path $($azDevOpsPipelinePath.FullName)
      }
      #endregion

      #region Setup GitHub Config
      if ($DevOpsSystem -eq 'GitHub') {
        $null = New-Item -Path "$Path/.github" -ItemType Directory -Force
        $githubWorkflowPath = New-Item -Path "$Path/.github/workflows" -ItemType Directory -Force
        New-GithubWorkflowFiles -Path $($githubWorkflowPath.FullName)
      }
      #endregion

      #region Setup VSCode Config and Git Hooks
      $vscodeSettings = New-Item -Path "$Path/.vscode" -ItemType Directory -Force
      New-VSCodeSettingsFile -Path "$($vscodeSettings.FullName)/settings.json"
      $null = New-Item -Path "$Path/hooks" -ItemType Directory -Force
      #endregion

      #region Setup Scripts folder and files
      $null = New-Item -Path "$Path/scripts" -ItemType Directory -Force
      $null = New-Item -Path "$Path/scripts/pipelines" -ItemType Directory -Force
      $null = New-Item -Path "$Path/scripts/tools" -ItemType Directory -Force
      #endregion

      #region Setup Azure folder
      $azurePath = New-Item -Path "$Path/Azure" -ItemType Directory -Force

      #endregion

      #region Setup Tests folder
      $null = New-Item -Path "$Path/tests" -ItemType Directory -Force
      #endregion

      '# CloudGrip' | Out-File -FilePath "$Path/README.md" -Encoding utf8 -Force
    }
  }

  end {}
}

<#
  .SYNOPSIS
  The synopsis of the new function

  .DESCRIPTION
  The description of the new function

  .PARAMETER TenantId
  The name of the parameter

  .EXAMPLE
  Register-CA8CloudGripSPN -TenantId "00000000-0000-0000-0000-000000000000"

#>
function Register-CA8CloudGripSPN {
  [CmdLetBinding(SupportsShouldProcess = $true)]
  [Diagnostics.CodeAnalysis.SuppressMessageAttribute('PSAvoidUsingConvertToSecureStringWithPlainText', '')]
  [Diagnostics.CodeAnalysis.SuppressMessageAttribute('ScriptAnalyzerRules\Measure-StringLiteralDoubleQuoted', '')]
  Param(
    [Parameter()]
    [string] $TenantId
  )

  begin {

  }
  process {
    if ($PSCmdlet.ShouldProcess($TenantId, 'Register CloudGrip SPN and configure permissions')) {
      #region Install required modules
      if ($null -eq (Get-Module -ListAvailable Microsoft.Graph.Applications)) {
        Install-Module -Name Microsoft.Graph.Applications -RequiredVersion 2.16.0 -Repository PSGallery -Force
      }
      if ($null -eq (Get-Module -ListAvailable Az.Accounts)) {
        Install-Module -Name Az.Accounts -RequiredVersion 2.13.2 -Repository PSGallery -Force
      }
      if ($null -eq (Get-Module -ListAvailable Az.Resources)) {
        Install-Module -Name Az.Resources -RequiredVersion 6.12.1 -Repository PSGallery -Force
      }
      #endregion

      #region Configure SPN
      $null = Connect-AzAccount -Tenant $TenantId -Scope Process -ErrorAction Stop
      $token = (Get-AzAccessToken -ResourceTypeName MSGraph -ErrorAction Stop).token
      Connect-MgGraph -AccessToken (ConvertTo-SecureString -String $token -AsPlainText -Force) -NoWelcome
      # Connect-MgGraph -Scopes "AppRoleAssignment.ReadWrite.All", "Application.ReadWrite.All" -TenantId $TenantId
      $servicePrincipalID = @{
        'AppId' = '80b3a93d-c828-4d6a-87c6-68b74b3a6557'
      }
      $null = New-MgServicePrincipal -BodyParameter $servicePrincipalID
      $msGraph = Get-MgServicePrincipal -Filter "displayName eq 'Microsoft Graph'" -Property 'id,displayName,appId,appRoles' #GraphAggregatorService
      $appregMgSetup = Get-MgServicePrincipal -Filter "displayName eq 'CloudGrip - Setup'" -Property 'id,displayName,appId,appRoles'
      $params = @{
        principalId = $appregMgSetup.Id
        resourceId  = $msGraph.Id
        appRoleId   = '18a4783c-866b-4cc7-a460-3d5e5662c884'
      }
      $null = New-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $appregMgSetup.Id -BodyParameter $params

      $params = @{
        principalId = $appregMgSetup.Id
        resourceId  = $msGraph.Id
        appRoleId   = '06b708a9-e830-4db3-a914-8e69da51d44f'
      }
      $null = New-MgServicePrincipalAppRoleAssignedTo -ServicePrincipalId $appregMgSetup.Id -BodyParameter $params
      $null = New-AzRoleAssignment -ObjectId $appregMgSetup.Id -RoleDefinitionName 'User Access Administrator' -Scope '/'
      Write-Information -MessageData 'CloudGrip SPN registered and permissions configured' -InformationAction Continue
    }
  }

  end {}
}

Export-ModuleMember -Function @(
    'New-CA8CloudGripSetup'
    'Register-CA8CloudGripSPN'
)
